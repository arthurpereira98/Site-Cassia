﻿// Write your Javascript code.
function ProcurarClienteCPF(cpf) 
{ 
    $.ajax({ 
        type: 'GET', 
        url: '/Sistema/ProcurarCliente?cpf='+cpf, 
        data: cpf, 
        success: function (data) {             
            console.log(JSON.stringify(data, null, 4)); 
            if (data != null) { 
                var Cliente = JSON.parse(JSON.stringify(data, null, 4)); 
                window.location = "/Sistema/Cliente?idCliente=" + Cliente.idCliente;                  
            } else { 
                alert("CPF Incorreto !");                 
            } 
        } 
    }); 
}

