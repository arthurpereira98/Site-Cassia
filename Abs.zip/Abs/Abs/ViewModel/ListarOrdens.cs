using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Absoluta.Models;

namespace Absoluta.ViewModel
{
    public class ListarOrdens
    {
        public List<Ordem> Ordens { get; set; }
    }
}
