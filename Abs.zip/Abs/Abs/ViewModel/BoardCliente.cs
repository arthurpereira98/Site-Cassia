﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Absoluta.Models;

namespace Absoluta.ViewModel
{
    public class BoardCliente
    {
        public Cliente Cliente { get; set; }
        public List<Ordem> Ordens { get; set; }
    }
}
