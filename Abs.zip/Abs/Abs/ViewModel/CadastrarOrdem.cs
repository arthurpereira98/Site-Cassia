﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Absoluta.Models;

namespace Absoluta.ViewModel
{
    public class CadastrarOrdem
    {
        public List<Categoria> Categorias { get; set; }
        public Cliente Cliente { get; set; }
        public Ordem Ordem { get; set; }
        public List<StatusOrdem> StatusOrdem { get; set; }
        public ItemHistorico Entrada { get; set; }
        public ItemHistorico Entrega { get; set; }
    }
}
