﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Absoluta.Models
{
    public class AbsolutaContext : DbContext
    {
        public AbsolutaContext(DbContextOptions<AbsolutaContext> options) : base(options)
        {

        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Cliente>()
                .HasKey(p => p.IdCliente);
            modelBuilder.Entity<Ordem>()
                .HasKey(p => p.IdOrdem);
            modelBuilder.Entity<Cliente>()
                .HasAlternateKey(p => p.Celular);
            modelBuilder.Entity<Categoria>()
                .HasKey(p => p.CategoriaId);
            modelBuilder.Entity<StatusOrdem>()
                .HasKey(p => p.IdStatus);
            modelBuilder.Entity<ItemHistorico>()
                .HasKey(p => p.IdHistorico);
            modelBuilder.Entity<Usuario>()
                .HasKey(p => p.UserId);
        }
        public DbSet<Cliente> Clientes { get; set; }
        public DbSet<Ordem> Ordens { get; set; }
        public DbSet<Categoria> Categorias { get; set; }
        public DbSet<StatusOrdem> StatusOrdem { get; set; }
        public DbSet<ItemHistorico> ItensHistorico { get; set; }
        public DbSet<Usuario> Usuarios { get; set; }
    }
}
