﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Absoluta.Models
{
    public class ItemHistorico
    {
        public int IdHistorico { get; set; }
        public int IdOrdem { get; set; }
        public int IdStatus { get; set; }
        public DateTime Data { get; set; }
    }
}
