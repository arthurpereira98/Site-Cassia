﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Absoluta.Models
{
    public class Cliente
    {
        public int IdCliente { get; set; }
        [Required]
        public string Nome { get; set; }
        [Required]
        public string Email { get; set; }
        [Required]
        public string Celular { get; set; }
        public string TelRecado { get; set; }
        [Required]
        public string CPF { get; set; }
        public string Endereco { get; set; }
        public string Referencia { get; set; }
    }
}
