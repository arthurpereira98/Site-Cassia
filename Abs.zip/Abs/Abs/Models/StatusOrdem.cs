﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Absoluta.Models
{
    public class StatusOrdem
    {
        public int IdStatus { get; set; }
        public String NomeStatus { get; set; }
    }
}
