﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Absoluta.Models
{
    public class Ordem
    {
        public int IdOrdem { get; set; }
        [Required]
        public int CategoriaId { get; set; }
        [Required]
        public int IdCliente { get; set; }
        public float Valor { get; set; }
        public string Descricao { get; set; }
        public string Observacoes { get; set; }
        public DateTime Prazo { get; set; }
        public int Status { get; set; }
    }
}
