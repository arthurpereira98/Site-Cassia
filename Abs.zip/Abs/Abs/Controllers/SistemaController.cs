﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Absoluta.Models;
using Absoluta.ViewModel;
using System.Text;
using static Absoluta.Classes.Utilites;
using Microsoft.AspNetCore.Http;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Absoluta.Controllers
{
    public class SistemaController : Controller
    {
        private AbsolutaContext _AbsolutaContext;

        public SistemaController(AbsolutaContext e)
        {
            _AbsolutaContext = e;
            _AbsolutaContext.Database.EnsureCreated();
            if (_AbsolutaContext.StatusOrdem.Count() == 0) {
                StatusOrdem Retirado = new StatusOrdem();
                Retirado.NomeStatus = "Retirado";
                _AbsolutaContext.Add(Retirado);

                StatusOrdem Processando = new StatusOrdem();
                Retirado.NomeStatus = "Processando";
                _AbsolutaContext.Add(Processando);

                StatusOrdem Entregue = new StatusOrdem();
                Retirado.NomeStatus = "Entregue";
                _AbsolutaContext.Add(Entregue);
            }
        }
        // GET: /<controller>/
        public IActionResult Index()
        {
            if (!CheckSession()) { return RedirectToAction("Login", "Sistema"); }
            return View();
        }
        public IActionResult NovaCategoria()
        {
            if (!CheckSession()) { return RedirectToAction("Login", "Sistema"); }
            return View();
        }
        public IActionResult Ordens()
        {
            if (!CheckSession()) { return RedirectToAction("Login", "Sistema"); }
            ListarOrdens _ListOrdens = new ListarOrdens();
            _ListOrdens.Ordens = _AbsolutaContext.Ordens.OrderBy(o => o.Prazo).Where(p => p.Status == 1).ToList();
            Categoria[] _Categorias = new Categoria[_AbsolutaContext.Categorias.Count()];
            _Categorias = _AbsolutaContext.Categorias.ToArray();
            ViewBag.Categorias = _Categorias;
            return View(_ListOrdens);
        }
        public IActionResult PagTeste()
        {
            if (!CheckSession()) { return RedirectToAction("Login", "Sistema"); }
            return View();
        }
        [HttpGet]
        public IActionResult NovaOrdem()
        {
            if (!CheckSession()) { return RedirectToAction("Login", "Sistema"); }
            string strCliId = HttpContext.Request.Query["IdCliente"];
            string strAt = HttpContext.Request.Query["At"];
            int At = 0;
            Cliente _Cliente = new Cliente();
            if (strAt != null && strAt != "") {
                At = int.Parse(strAt);
            }
            if (strCliId != null && strCliId != "") {
                int id = int.Parse(strCliId);
                _Cliente = _AbsolutaContext.Clientes
                    .Where(p => p.IdCliente == id)
                    .SingleOrDefault();
            }
            CadastrarOrdem _CadOrdem = new CadastrarOrdem();

            _CadOrdem.Cliente = _Cliente;
            _CadOrdem.Categorias = _AbsolutaContext.Categorias.ToList();
            if (At != 0)
            {
                ViewBag.Atualizados = At;
            }
            else
            {
                ViewBag.Atualizados = 0;
            }

            return View(_CadOrdem);
        }

        [HttpPost]
        public IActionResult NovaCategoria(Categoria _Categoria) {
            if (!CheckSession()) { return RedirectToAction("Login", "Sistema"); }
            int _Atualizados = 0;
            if (_Categoria.CategoriaId == 0) {
                _AbsolutaContext.Categorias.Add(_Categoria);
                _Atualizados = _AbsolutaContext.SaveChanges();
            }
            else {
                _AbsolutaContext.Update(_Categoria);
                _Atualizados = _AbsolutaContext.SaveChanges();
            }
            return RedirectToAction("NovaCategoria", "Sistema", new { At = _Atualizados });
        }

        [HttpGet]
        public IActionResult NovaCategoria(int At) {
            if (!CheckSession()) { return RedirectToAction("Login", "Sistema"); }
            if (At != 0) {
                ViewBag.Atualizados = At;
            }
            else {
                ViewBag.Atualizados = 0;
            }
            return View();
        }

        [HttpGet]
        public IActionResult NovoCliente() {
            if (!CheckSession()) { return RedirectToAction("Login", "Sistema"); }
            return View();
        }

        [HttpPost]
        public IActionResult NovoCliente(Cliente _Cliente)
        {
            if (!CheckSession()) { return RedirectToAction("Login", "Sistema"); }
            int _Atualizados = 0;
            if (_Cliente.IdCliente == 0)
            {
                _AbsolutaContext.Clientes.Add(_Cliente);
                _Atualizados = _AbsolutaContext.SaveChanges();
            }
            else
            {
                _AbsolutaContext.Update(_Cliente);
                _Atualizados = _AbsolutaContext.SaveChanges();
            }
            ViewBag.Atualizados = _Atualizados;
            return RedirectToAction("Cliente", "Sistema", new { IdCliente = _Cliente.IdCliente });
        }
        [HttpPost]
        public IActionResult NovaOrdem(Ordem _Ordem)
        {
            if (!CheckSession()) { return RedirectToAction("Login", "Sistema"); }
            int _Atualizados = 0;
            if (_Ordem.IdOrdem == 0)
            {
                _AbsolutaContext.Ordens.Add(_Ordem);
                _Atualizados = _AbsolutaContext.SaveChanges();
                ItemHistorico Retirada = new ItemHistorico();
                Retirada.IdOrdem = _Ordem.IdOrdem;
                Retirada.IdStatus = 1;
                Retirada.Data = DateTime.Now;
            }
            else
            {
                _AbsolutaContext.Update(_Ordem);
                _Atualizados = _AbsolutaContext.SaveChanges();
            }
            ViewBag.Atualizados = _Atualizados;
            return RedirectToAction("NovaOrdem", "Sistema", new { At = _Atualizados });
        }

        [HttpGet]
        public IActionResult ProcurarCliente(string cpf)
        {
            if (!CheckSession()) { return RedirectToAction("Login", "Sistema"); }
            Cliente _Cliente = new Cliente();
            _Cliente = _AbsolutaContext.Clientes.Where(p => p.CPF == cpf).FirstOrDefault();
            return Json(_Cliente);
        }
        [HttpGet]
        public IActionResult Ordem([FromQuery]int id) {
            if (!CheckSession()) { return RedirectToAction("Login", "Sistema"); }
            CadastrarOrdem _CadOrdem = new CadastrarOrdem();
            int OrdemId = id;

            _CadOrdem.Ordem = _AbsolutaContext.Ordens
                                .Where(o => o.IdOrdem == OrdemId)
                                .FirstOrDefault();
            _CadOrdem.Categorias = _AbsolutaContext.Categorias
                                .OrderBy(o => o.CategoriaId)
                                .ToList();
            _CadOrdem.Cliente = _AbsolutaContext.Clientes
                                .Where(c => c.IdCliente == _CadOrdem.Ordem.IdCliente)
                                .FirstOrDefault();
            _CadOrdem.StatusOrdem = _AbsolutaContext.StatusOrdem
                                .OrderBy(s => s.IdStatus)
                                .ToList();
            return View(_CadOrdem);
        }


        [HttpGet]
        public IActionResult Cliente(int idCliente)
        {
            if (!CheckSession()) { return RedirectToAction("Login", "Sistema"); }
            if (idCliente == 0){
                 return RedirectToAction("NovoCliente", "Sistema");
            }
            BoardCliente _BCliente = new BoardCliente();
            Cliente _Cliente = new Cliente();
            _Cliente = _AbsolutaContext.Clientes.Where(p => p.IdCliente == idCliente).FirstOrDefault();
            _BCliente.Cliente = _Cliente;
            _BCliente.Ordens = _AbsolutaContext.Ordens
                                    .Where(o => o.IdCliente == idCliente)
                                    .ToList();
            Categoria[] _Categorias = new Categoria[_AbsolutaContext.Categorias.Count()];
            _Categorias = _AbsolutaContext.Categorias.ToArray();
            ViewBag.Categorias = _Categorias;
            return View(_BCliente);
        }
        [HttpGet]
        public IActionResult CadastrarUsuario()
        {
            if (!CheckSession()) { return RedirectToAction("Login", "Sistema"); }
            return View();
        }
        [HttpPost]
        public IActionResult CadastrarUsuario(Usuario user)
        {
            if (!CheckSession()) { return RedirectToAction("Login", "Sistema"); }
            if (_AbsolutaContext.Usuarios.Where(p => p.Login == user.Login).Count() == 0)
            {

                Random random = new Random();
                user.Salt = random.Next(11111111, 99999999).ToString();                
                user.Password = HashPass(user.Password, user.Salt);
                _AbsolutaContext.Add(user);
                _AbsolutaContext.SaveChanges();
            }
            else
            {
                return RedirectToAction("CadastrarUsuario", "Sistema");
            }
            return RedirectToAction("Logar", "Sistema");
        }
        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Login(Usuario user)
        {
            if(user.Login != null && user.Login != "" && user.Password != "")
            {
                Usuario _User = _AbsolutaContext.Usuarios.Where(p => p.Login == user.Login).FirstOrDefault();
                user.Password = HashPass(user.Password, _User.Salt);
                if(user.Password == _User.Password)
                {
                    HttpContext.Session.SetString("HashPass",user.Password);
                    HttpContext.Session.SetString("UserId", _User.UserId.ToString());
                }
                else
                {
                    return RedirectToAction("Login", "Sistema");
                }
            }
            return RedirectToAction("Index", "Sistema");
        }
        public IActionResult AdicionarImagem()
        {
            return View();
        }
        public Boolean CheckSession()
        {
            string UId = HttpContext.Session.GetString("UserId");
            if (!String.IsNullOrEmpty(UId))
            {
                int UserId = Int32.Parse(UId);
                string uPHash = _AbsolutaContext.Usuarios.Where(p => p.UserId == UserId).Select(p => p.Password).FirstOrDefault();
                if(uPHash == HttpContext.Session.GetString("HashPass"))
                {
                    return true;
                }
            }
            return false;            
        }
    }
}
